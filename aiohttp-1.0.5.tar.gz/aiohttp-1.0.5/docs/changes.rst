.. include:: ../CHANGES.rst

.. include:: ../HISTORY.rst


.. disqus::
  :title: aiohttp changelog
